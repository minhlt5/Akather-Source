"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    corsOrigin: "*",
    port: 8080,
    host: "localhost",
};
